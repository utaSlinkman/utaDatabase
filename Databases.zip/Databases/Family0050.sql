INSERT INTO Person
            VALUES( 14, 'Slinkman', 'Peyton',    NULL, 10, 13 ),
                  ( 15, 'Slinkman', 'Ella',      NULL, 10, 13 ),
                  ( 16, 'Slinkman', 'Samantha',  NULL, 10, 13 ),
                  ( 17, 'Baker',    'Elizabeth', NULL,  9, 11 ),
                  ( 18, 'Baker',    'Ryan',      NULL,  9, 11 ),
                  ( 19, 'Van Buren', 'Andrew',   NULL,  8,  12 ),
                  ( 20, 'Van Buren', 'Rachel',   NULL,  8, 12 );
                  
