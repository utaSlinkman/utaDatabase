-- Show the current date

SELECT    Date('now')