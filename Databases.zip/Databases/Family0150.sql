-- Alter table add column

Alter Table Person
    ADD Column deceased Char(1) 
        CHECK( deceased in ( 'Y', 'N' ) );

