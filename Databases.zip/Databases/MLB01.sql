Select   Salaries.lgID,
         Salaries.teamID,
         Salaries.yearID,
         Teams.W as Wins,
         sum( Salaries.salary )  teamSalary        
FROM     Salaries NATURAL JOIN Teams
WHERE    Salaries.yearID >= 1990
GROUP BY Salaries.lgID,
         Salaries.teamID

