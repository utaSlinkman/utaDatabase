INSERT INTO Person
            VALUES( 8, 'Van Buren', 'Vicky', '1983-04-01', 6, 3 ),
                  ( 9, 'Baker', 'Erin', '1985-02-14', 6, 3 ),
                  ( 10, 'Sinkman', 'Danny', '1988-08-08', 6, 3 )
    