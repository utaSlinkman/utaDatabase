SELECT   *
FROM     Person