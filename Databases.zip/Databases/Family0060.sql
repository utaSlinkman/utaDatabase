--Family selfjoin

-- List every Person and their mother

SELECT   C.lastNAME || ', ' || C.firstName as Child,
         M.lastNAME || ', ' || C.firstNAME as Mother
  
FROM     PERSON C,
         PERSON M
WHERE C.motherID = M.personID

                  
