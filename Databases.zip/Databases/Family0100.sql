-- Compute the age of Craig Slinkman

-- Note that we substract -0.5 to esnure that we always round down because
-- SQLite foes not have a floor function

SELECT  firstName AS "First Name",
        lastNAME AS "Last Name",
round( ( julianday('now') - julianday( birthDate )) /365.25 - 0.5 ) as Age
FROM    Person
WHERE   lastNAME = 'Slinkman'
  AND   firstName = 'Craig'