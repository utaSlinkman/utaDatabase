-- What is the oungest person in the table ignoring
-- all persons whose birthdate we know

SELECT   max( birthDate )
FROM     Person



