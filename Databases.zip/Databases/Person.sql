CREATE TABLE Person
(
    personID INT Primary Key,
    lastName varchar( 64 ) NOT NULL,
    firtNAME varchar( 32 ) NOT NULL,
    birthDate DATE,
    mootherID INT REFERENCES Person(personID),
    fatherID INT REFERENCES Person(personID)
);