-- Chinook0020.sql

--Natural Join

Select     Customer.LastName  ||
           ', ' ||
           Customer.FirstName,
           Invoice.InvoiceDate,
           Invoice.Total
FROM       Customer Natural Join Invoice
ORDER BY   Customer.LastName,
           Customer.FirstName
        
            
