SELECT  NameLast || ',  '  || nameFirst as Player,
        yearID AS year,
        salary
FRom    Master,
        Salaries
WHERE   Master.playerID = Salaries.playerID
  AND   Salaries.yearID > 1999
ORDER BY salary DESC,
         yearID