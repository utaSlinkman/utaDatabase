---Count function

-- Count the number of people with the last neame
--of baker.

SELECT    count(*)
FROM      Person
WHERE     lastNAME = 'Baker'  
