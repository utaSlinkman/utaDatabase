
-- Compute the percentage of deceased persons in the Person table

SELECT 100* ( SELECT CAST( count(*) as float ) FROM Person where deceased = 'Y' ) /
            ( SELECT CAST( count(*) as FLOAT ) FROM Person )