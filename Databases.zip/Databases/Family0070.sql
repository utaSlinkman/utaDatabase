--Left outer self-join

--List all the children and their mothers

SELECT    C.lastName || ', ' || C.firstNAME as Child,
          M.lASTname || ', ' || M.firstNAME as Mother
FROM      Person C
              LEFT OUTER JOIN
          Person M
              ON C.personID = M.motherID
          