SELECT  *
FROM    Person
    