CREATE TABLE Person
(
    personID INT Primary Key,
    lastName varchar( 64 ) NOT NULL,
    firstNAME varchar( 32 ) NOT NULL,
    birthDate DATE,
    motherID INT REFERENCES Person(personID),
    fatherID INT REFERENCES Person(personID)
);